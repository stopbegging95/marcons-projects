<?php include("include/header.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
<div id="banner" >
     <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" style="bvackground-color:black;">
          <!-- <ol class="carousel-indicators">
          <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
          </ol> -->
          <div class="carousel-inner">
          <div class="carousel-item active" >
               <img src="images/2.jpg" class="wow zoomIn d-block w-100" alt="...">
               <div class="carousel-caption" >
               
                    <!-- <h5 class="typewrite" data-period="3000" data-type='[ "Welcome to", "Here we are", "We are here because"]'>
                         <span class="wrap"></span>
                    </h5> -->
               
               <!-- <h5 id="firstcarhfive" class=" hidden5">Welcome to </h5> -->
               <!-- <p> MARCONS PROJECTS INT'L NIG. LTD.</p> -->
                    
               <p class="wow rotateInDownRight" id="data-type">
                         <a class="typewrite" data-period="2000" data-type='[ "<h5> Welcome to </h5> <br> MARCONS PROJECTS INT&#39;L NIG. LTD.", " <h5> Here we are </h5> <br> Your Number 1 Creative and Renovation Solution", " <h5> We are here because </h5> <br> You Have Got The Idea? We Can Bring It To Reality." ]'>
                         <span class="wrap"></span>
                         </a>
                    </p>

                    <!-- <p class="wow rotateInDownRight" id="data-type">
                         <a class="typewrite" data-period="2000" data-type='[ "MARCONS PROJECTS INT&#39;L NIG. LTD.", "Your Number 1 Creative and Renovation Solution", "You Have Got The Idea? We Can Bring It To Reality." ]'>
                         <span class="wrap"></span>
                         </a>
                    </p> -->
               </div>
          </div>
          <div class="carousel-item">
               <img src="images/1.jpg" class="d-block w-100" alt="...">
               <div class="carousel-caption ">
               <h5> We are the</h5>
               <p>Leaders In Delivering World Architecture, <br> That Will Transform Your Vision.</p>
                    <!-- <p class="wow rotateInDownRight">
                         <a href="" class="typewrite" data-period="4000" data-type='[ "Leaders In Delivering World Architecture", "Artchitect Transform Your Vission", "New Evolution For Your Business." ]'>
                         <span class="wrap"></span>
                         </a>
                    </p> -->
               </div>
          </div>
          <div class="carousel-item">
               <img src="images/5.jpg" class="d-block w-100" alt="...">
               <div class="carousel-caption ">
               <h5>For many years</h5>
               <p>Devoted To Superior Quality Results, <br> With New Evolution For Your Business.</p>
               </div>
          </div>
          </div>
          <a class="carousel-control-prev " href="#carouselExampleCaptions" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
          </a>
     </div>
</div> <!-- #End banner -->
 
<div id="indexAbout" class="jumbotron jumbotron-fluid">
  <div class="container">
       
          <h3 class="display-4">Who We Are </h3>
          <p class="lead">MARCONS is a company driven to provide quality construction management and development 
               services to our clients. Working as a team, each one contributing in building the best, meeting the diverse needs 
               of the people we serve, using technology, research and innovation to build projects that last.
          </p>
      
  </div>
</div>

<div id="indexServices" class="container-fluid">
  <div class="wow rotateInDownRight container col-12">

     <h3> Our Area Of Specialization </h3>
      <div class="row">
         <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 spec" id="first" > 
              <h4> Design and Pro Services</h4>
                    <ul>
                              <li>  Architecture and Structural Designs </li>
                              <li>  Site Survey Planning </li>
                              <li>  Cost Estimation and BOQ </li>
                              <li> Project Management </li>
                              <li> Illuminated Archi Model </li>
                              <li> Quality Assurance Check </li>
                           
                    </ul>
          </div>
         <div class="col-sm-6 col-md-3 col-lg-3  spec" id="second"> 
              <h4> Civil Engr. Constructions </h4>
                    <ul>
                              <li> Turnkey Projects </li>
                              <li> Remodeling and Renovation </li>
                              <li> Road and Bridge Construction</li>
                              <li> Steel Fabrication </li>
                              <li> Pool and Pond Construction </li>
                              <li> Borehole and Geo-Surveys </li>   
                    </ul>
          </div>
         <div class="col-sm-6 col-md-3 col-lg-3  spec" id="third"> 
              <h4> Decoration and Finishes</h4>
                    <ul>
                              <li>  Alucobond Cladding </li>
                              <li>  Painting and POP works </li>
                              <li>  Aluminium and Glass works </li>
                              <li> Furniture and Cabinets </li>
                              <li> Wooden Floor and Skirting </li>
                              <li> Tiling </li>
                           
                    </ul>
          </div>
         <div class="col-sm-6 col-md-3 col-lg-3 spec" id="fourth"> 
              <h4> Building Materials and Real Estate </h4>
                    <ul>
                              <li>   Building Materials Supply </li>
                              <li>   Estate Planning and Development </li>
                              <li>  Buy and Sell Lands </li>
                              <li> Buy and Sell Properties </li>
                            
                    </ul>
          </div>
        </div> 
  </div>
</div>


<div id="indexProduct" class="container-fluid">
  <div class="container col-12">
       
     <h3 class=" wow fadeInRight"> Our Featured Projects </h3>
      
     <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <!-- <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol> -->

          <div class="carousel-inner">
               <div class="carousel-item active">
                    <div class="row" id="projectrow">
                         <div class="wow fadeInUp col-sm-3 col-md-3 col-lg-3 proclass" >
                         <img src="images/featured.jpg" alt="Snow" style="width:100%">
                         <section> 
                              <h4> YOACO BUNGALOW DESIGN </h4>
                              <p> <strong> Location </strong> Yoaco Area, Off Ilorin Road, Ogbomoso </p>
                         </section>
                         </div>
                         <div class="wow fadeInDown col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured2.jpg" alt="Forest" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class=" wow fadeInLeft col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured3.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="wow fadeInRight col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured4.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                    </div>
               
               </div>
               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured5.jpg" alt="Snow" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3  col-md-3 col-lg-3 proclass">
                         <img src="images/featured6.jpg" alt="Forest" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3  col-md-3 col-lg-3 proclass">
                         <img src="images/featured7.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured8.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                    </div>
               </div>
               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured9.jpg" alt="Snow" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured10.jpg" alt="Forest" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured11.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                         <div class="col-sm-3 col-md-3 col-lg-3 proclass">
                         <img src="images/featured12.jpg" alt="Mountains" style="width:100%">
                         <section> 
                              <h4> Heading Coming Soon </h4>
                              <p> <strong> Location </strong> dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. </p>
                         </section>
                         </div>
                    </div>
               </div>
      
          </div>

          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
          </a>
     </div>
  </div>
</div>


<div id="indexTestimony" class="container-fluid">
  <div class="container col-12">

     <h3> Our Clients Testimonies </h3>
     
     <div class="row" id="cont">
         
          <div class="card mb-3 col-4 wow fadeInLeft">
               <div class="row no-gutters">
                    <div  class="col-md-12 col-lg-4 contdyb">
                         <img src="images/mod.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-12  col-lg-8">
                         <div class="card-body">
                              <h5 class="card-title">Mr. Coming Soon</h5>
                              <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est.</p>
                         </div>
                    </div>
               </div>
          </div>

          <div class="card mb-3 col-4 wow fadeInUp">
               <div class="row no-gutters">
                    <div class="col-md-12 col-lg-4 contdyb">
                         <img src="images/mod.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-12 col-lg-8">
                         <div class="card-body">
                              <h5 class="card-title">Mr. Coming Soon</h5>
                              <p class="card-text"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est.</p>
                         </div>
                    </div>
               </div>
          </div>

          <div class="card mb-3 col-4 wow fadeInRight">
               <div class="row no-gutters">
                    <div class="col-md-12 col-lg-4 contdyb">
                         <img src="images/mod.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-12  col-lg-8">
                         <div class="card-body">
                              <h5 class="card-title">Mr. Coming Soon</h5>
                              <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est.</p>
                         </div>
                    </div>
               </div>
          </div>


     </div>
          
  </div>
</div>

<div id="indexNewsLetter" class="container-fluid">
  <div class="wow rotateInDownRight container col-12">

     <h3> Subscribe Now To Our News Letter </h3>
  
                    
          <form id="subform" class="col-sm-10 offset-sm-1 col-lg-8 offset-lg-2" action="action_page.php">

               <div class="sub col-12 ">
                   
                    <div id="inputdiv" class="col-lg-12"> 
                         <input class="inp col-lg-5 col-sm-5" type="text" placeholder="Name" name="name" required>
                         <input class=" col-lg-5 col-sm-5" type="text" placeholder="Email address" name="mail" required>
                    </div> 


                    <label>
                         <input type="checkbox" name="subscribe"> Daily Newsletter
                    </label>

               </div>

               <div class="contsubainer">
               <input type="submit" value="Subscribe">
               </div>
          </form>
          
  </div>
</div>


<div id="indexDesign" class="container-fluid d-sm-none d-md-block d-none d-sm-block">
  <div class="container col-12">
       
     <h3 class=" wow fadeInRight"> Our Happy Clients </h3>
      
     <div id="carouselExampleIndicators2" class="carousel slide " data-ride="carousel">
          <!-- <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators2" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators2" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators2" data-slide-to="2"></li>
          </ol> -->

          <div class="carousel-inner">
               <div class="carousel-item active">
                    <div class="row" id="projectrow">
                         <div class="wow fadeInUp col-sm-2 col-lg-2 proclass" >
                         <img src="images/featured.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class="wow fadeInDown col-sm-2 col-lg-2 proclass">
                         <img src="images/featured2.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class=" wow fadeInLeft col-sm-2 col-lg-2 proclass">
                         <img src="images/featured3.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="wow fadeInRight col-sm-2 col-lg-2 proclass">
                         <img src="images/featured4.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="wow fadeInDown col-sm-2 col-lg-2 proclass">
                         <img src="images/featured2.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class=" wow fadeInLeft col-sm-2 col-lg-2 proclass">
                         <img src="images/featured3.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               
               </div>
               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured5.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured6.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured7.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured8.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured6.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured7.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               </div>
               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured9.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured10.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured11.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured12.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured11.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="col-sm-2 col-lg-2 proclass">
                         <img src="images/featured12.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               </div>
      
          </div>

        
          <a class="carousel-control-prev" href="#carouselExampleIndicators2" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators2" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
          </a>
     </div>
  </div>
</div>






<!-- <div id="indexDesign" class="container-fluid d-block d-sm-none">
  <div class="container col-12">
       
     <h3 class=" wow fadeInRight"> Our Happy Clients </h3>
      
     <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
          </ol>

          <div class="carousel-inner">
               <div class="carousel-item active">
                    <div class="row" id="projectrow">
                         <div class="wow fadeInUp proclass col-xs-3 col-sm-6" >
                         <img src="images/featured.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class="wow fadeInDown proclass col-xs-3 col-sm-6">
                         <img src="images/featured2.jpg" alt="Forest" style="width:100%">
                         </div>
                    </div>
               
               </div>

               <div class="carousel-inner">
               <div class="carousel-item active">
                    <div class="row" id="projectrow">
                         <div class=" wow fadeInLeft proclass col-xs-6 col-sm-6">
                         <img src="images/featured3.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="wow fadeInRight proclass col-xs-6 col-sm-6">
                         <img src="images/featured4.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               
               </div>
                <div class="carousel-item active">
                    <div class="row" id="projectrow">
                         <div class="wow fadeInDown  proclass proclass col-xs-6 col-sm-6">
                         <img src="images/featured2.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class=" wow fadeInLeft proclass proclass col-xs-6 col-sm-6">
                         <img src="images/featured3.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               
               </div>

               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured5.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured6.jpg" alt="Forest" style="width:100%">
                         </div>
                    </div>
               </div>

               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured7.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured8.jpg" alt="Mountains" style="width:100%">
                         </div>
               
                    </div>
               </div>
               
               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured6.jpg" alt="Forest" style="width:100%">
                         </div>
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured7.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               </div>
               


               <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured9.jpg" alt="Snow" style="width:100%">
                         </div>
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured10.jpg" alt="Forest" style="width:100%">
                         </div>
                    </div>
               </div>

                <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured11.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class=" proclass col-xs-6 col-sm-6">
                         <img src="images/featured12.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               </div>

                <div class="carousel-item">
                    <div class="row" id="projectrow">
                         <div class="  proclass col-xs-6 col-sm-6">
                         <img src="images/featured11.jpg" alt="Mountains" style="width:100%">
                         </div>
                         <div class="  proclass col-xs-6 col-sm-6">
                         <img src="images/featured12.jpg" alt="Mountains" style="width:100%">
                         </div>
                    </div>
               </div>

      
          </div>

        
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
          </a>
     </div>
  </div>
</div> -->
<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	