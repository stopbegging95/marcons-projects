(function ($) {
  "use strict";
  $(document).ready(function(){

$('#carouselExampleCaptions').carousel({
    interval: 16000
  });



   
  var TxtType = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 100) || 4000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};

TxtType.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
    }

    this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

    var that = this;
    var delta = 50 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }

    if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 50;
    }

    setTimeout(function() {
    that.tick();
    }, delta);
};

window.onload = function() {
    var elements = document.getElementsByClassName('typewrite');
    for (var i=0; i<elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
          new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    // INJECT CSS
    // var css = document.createElement("style");
    // css.type = "text/css";
    // css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
    // document.body.appendChild(css);
};


// our Client carousel

// $("#client_owl").owlCarousel({					 
//   autoPlay: 5000, //Set AutoPlay to seconds here					 
//   items : 4,
//   itemsDesktop : [1199,4],
//   itemsDesktopSmall : [980,4],
//   itemsTablet: [768,2],
//   itemsTabletSmall: [480,1],
//   itemsMobile : [320,1],							  
//   navigation : true,					 
// });


// mybutton = document.getElementById("myBtn");
// window.onscroll = function() {scrollFunction()};

//   function scrollFunction(){
//     if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20){
//       mybutton.style.display = "block";
//     } else {
//       mybutton.style.display = "none"
//     }
//   }


//   function topFunction(){
//     document.body.scrollTop = 0;
//     document.documentElement.scrollTop = 0;
//   }






});



})(jQuery);