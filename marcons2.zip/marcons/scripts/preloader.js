﻿$(document).ready(function ($) {
     $('.preloader-wrapper').fadeOut();
     $('body').removeClass('preloader-site');
});
$(window).load(function () {
     var Body = $('body');
     Body.addClass('preloader-site');
});