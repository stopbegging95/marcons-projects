<!DOCTYPE html>
<html>

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title> marcons construction </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="keywords" content="civil engineering construction company in nigeria, civil engineering company in nigeria, construction company in nigeria, catridge,
architectural company in nigeria, civil engineering construction company in lagos, civil engineering company in lagos, construction company in lagos,
architectural company in lagos,  civil engineering construction company in kwara state, civil engineering company in kwara state, construction company in kwara state,
architectural company in kwara state, civil engineering construction company in oyo state, civil engineering company in oyo state, construction company in oyo state,
architectural company in oyo state," />
<meta name="description" content="MARCONS is a company driven to provide quality construction management and development services to our clients. Working as a team, each one contributing in building the best, meeting the diverse needs of the people we serve, using technology, research and innovation to build projects that last." />

<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />

<link href="styles/fonts.css" rel="stylesheet" />
<link href="styles/bootstrap.min.css" rel="stylesheet" />
<link href="styles/jquery-ui.min.css" rel="stylesheet" />
<link href="styles/myglyphicons2.css" rel="stylesheet" />
<link href="styles/font-awesome.css" rel="stylesheet" />
<link href="styles/site.css" rel="stylesheet" />
<!-- <link href="styles/slider2.css" rel="stylesheet" /> -->
<link href="styles/animate.css" rel="stylesheet" />

<!-- #BeginEditable "styles" -->

<!-- #EndEditable -->
</head>
<body>
<div class="wrapper">
<header>

    <div class="container col-12">
        
        <div class="row col-12" id="uppernav">
            
            <div class="col-sm-7 col-md-8 col-lg-8  uppercon"> 

                <h6> <span class="glyphicons glyphicons-headphones" ></span> <i> Help desk: </i> +(234)-8129-963-050,  +(234)-8038-452-144  </h6> <h6 class="d-none d-md-block"> <span class="fa fa-clock-o" ></span> <i> Working Time: </i> 8:00AM - 6:00PM </h6>

            </div>

            <div class="col-sm-5 col-md-4 col-lg-4 ml-auto uppercon" id="upperconmail"> 
               
               <h6> <span class="glyphicons glyphicons-envelope pull-left" ></span> <i> Email: </i> lamavens2020@gmail.com </h6>
               <a class="d-none d-md-block med" target="_blank" href="https://www.facebook.com/marconsprojects/" title="Facebook"><span class="fa fa-facebook "></span> </a>
               <a class="d-none d-md-block med" target="_blank" href="#" title="Twitter"><span class="fa fa-twitter"></span> </a>
               <a class="d-none d-md-block med" target="_blank" href="https://www.instagram.com/marcons_projects?r=nametag" title="Instagram"><span class="fa fa-instagram"></span> </a>
               <a class="d-none d-md-block med" target="_blank" href="https://wa.me/+2348129963050" title="WhatsApp"><span class="fa fa-whatsapp"></span> </a>
          
            </div>

        </div>

		<nav class="navbar navbar-expand-lg col-12">
               <a class="navbar-brand col-xs-6 col-sm-4 col-lg-3" href="/">
                    <img class="img-fluid" src="images/logo2.png" />
               </a>
               <button class=" navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
               </button>

               <div class="collapse navbar-collapse col-lg-7 offset-lg-2" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                         <li class="nav-item active">
                              <a class="nav-link" href="index.php"> HOME <span class="sr-only">(current)</span></a>
                         </li>
                         <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> ABOUT US
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="whoweare.php"> Who We Are</a>
                                   <a class="dropdown-item" href="ourteam.php"> Our Team</a>
                              </div>
                         </li>
                       
                         <li class="nav-item">
                              <a class="nav-link" href="ourprojects.php"> PROJECTS </a>
                         </li>
                        
                         <!-- <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> SERVICES
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="products.php"> Products</a>
                                   <a class="dropdown-item" href="faqs.php"> FAQs</a>
                              </div>
                         </li> -->
                       
                         <li class="nav-item">
                              <a class="nav-link" href="contactus.php"> CONTACT</a>
                         </li>
                         <li class="nav-item">
                              <a class="nav-link" href="blog.php"> BLOG </a>
                         </li>
                    </ul>
                  
               </div>
          </nav>
	</div>
     </header>