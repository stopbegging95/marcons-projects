<footer style="background-color:black !important;">

<!-- <button onclick="topFunction()" id="myBtn" title="Go to top"> Top </button> -->

     	<div class="container col-12" >
               <div class="row " id="foot"  style="border-bottom: 2px solid white !important;">
     			<div class="d-none d-md-block col-xs-12 col-sm-4 col-md-3 col-lg-3 footcon">
                              <h4> Who We Are </h4> 
                              <p class="lead" id="lead" >MARCONS is a company driven to provide quality construction management and development 
                                   services to our clients. Working as a team, each one contributing in building the best, meeting the diverse needs 
                                   of the people we serve, using technology, research and innovation to build projects that last.
                              </p>
                            
                    </div>

     			<div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 footcon">
                              <h4> Follow Us</h4>
                              <ul>
                                   <li>  <a href="https://www.facebook.com/marconsprojects/" title="Facebook" target="_blank"><span class="fa fa-facebook"></span> Facebook</a> </li>
                                   <li>  <a href="#" title="Instagram"><span class="fa fa-twitter" target="_blank"></span> Twitter </a> </li>
                                   <li>  <a href="https://www.instagram.com/marcons_projects?r=nametag" title="Instagram" target="_blank"><span class="fa fa-instagram"></span> Instagram</a> </li>
                                   <li>  <a href="https://wa.me/+2348129963050" title="whatsApp" target="_blank"><span class="fa fa-whatsapp"></span> WhatsApp</a> </li>
                              </ul>
                    </div>

                    <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 footcon">
                              <h4> Contact Address </h4>
                              <ul>
                                   <li class="address"> No. 3, Osemeka Street, Orile Iganmu, Lagos. </li>
                                   <li class="address"> Orita Naira, Opp. D.C School,    	Ogbomoso. </li>
                                   <li class="address"> G8 Akinrimisa Area, Aroro Makinde Ojoo. Ibadan,Oyo State, Nig.  </li>
                               
                               
                                   

                              </ul>
                    </div>
                    
     			<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 footcon">
                              <h4> Contact Form</h4>
                              
                              <form class="col-11" action=" <?=$_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                                <div class="success"> <?= $success ?? '' ?> </div>
                                                <div class="form-group">
                                                <input type="text" name="full_name" class="form-control" id="full_name" placeholder="Full Name"  value="<?= $full_name ?? '' ?>" required />
                                                <span class="error"><?= $full_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="email" name="email" class="form-control" id="email" placeholder="name@example.com"  value="<?= $email ?? '' ?>" required />
                                                <span class="error"><?= $email_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="tel" name="mobile" class="form-control" id="mobile" placeholder="Phone No: +(234)-8165-371-302" value="<?= $mobile ?? '' ?>" required  />
                                                <span class="error"><?= $mobile_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="text" name="company_name" class="form-control" id="companyname" placeholder="Company Name"  value="<?= $company_name ?? '' ?>" required />
                                                <span class="error"><?= $company_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <textarea type="text" name="company_message" class="form-control" id="exampleFormControlTextarea1" placeholder="Type your message" rows="3" value="<?= $company_message ?? '' ?>" required ></textarea>
                                                <span class="error"><?= $company_message_error ?? '' ?></span>
                                                </div>
                                        <button class="btn btn-success" name="submit" value="submit" type="submit"> <span class="glyphicons glyphicons-circle-arrow-right"> </span> Send Message</button>
                              </form>
                              
     			</div>
               </div>
               
     		<div class="row" id="bottomdiv">
     			<div class="col-xs-12 col-sm-8 col-md-8 col-lg-5 text-left">
     				<p >&copy;<?php echo date("Y"); ?> all rights reserved. Marcons Project Int'l Nig. Ltd  </p>
     			</div>
     			<div class="col-xs-12 col-sm-4 col-md-4 offset-lg-4 col-lg-3">
     				<p id="reserve">  <a href="https://cinsol.com.ng/" title="CINSOL">Developed by CINSOL </a> </p>
     			</div>
     		</div>
     	</div>
     </footer>
	 <script type="text/javascript" src="scripts/jquery-3.3.1.min.js"></script>
     <script type="text/javascript" src="scripts/popper.min.js"></script>
     <script type="text/javascript" src="scripts/bootstrap.min.js"></script>
     <script type="text/javascript" src="scripts/jquery-ui.min.js"></script>
     <script type="text/javascript" src="scripts/script.js"></script>
     <script type="text/javascript" src="scripts/wow.min.js"></script>
     <script type="text/javascript">
          var wow = new WOW(
               {
                    boxClass: 'wow',      // animated element css class (default is wow)
                    animateClass: 'animated', // animation css class (default is animated)
                    offset: 0,          // distance to the element when triggering the animation (default is 0)
                    mobile: true,       // trigger animations on mobile devices (default is true)
                    live: true,       // act on asynchronously loaded content (default is true)
                    callback: function (box) {
                         // the callback is fired every time an animation is started
                         // the argument that is passed in is the DOM node being animated
                    },
                    scrollContainer: null // optional scroll container selector, otherwise use window
               }
          );
          wow.init();
     </script>
     <!-- #BeginEditable "scripts" -->

	<!-- #EndEditable -->
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
     </div>
</body>

</html>
