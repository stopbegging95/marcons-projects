<?php //require("connection.php"); ?>
<?php

        $email_to = "lamavens2020@gmail.com";
        $email_subject = "Client Complain";

    // define variables and set to empty values
    $full_name_error = $email_error = $mobile_error = $company_name_error = $company_message_error = $message_error = "";
    $full_name = $email = $mobile = $company_name = $company_message = $success = "";

    // form is submitted with post method
    if ($_SERVER["REQUEST_METHOD"] == "POST") {


            if (        
                    !isset($_POST['full_name']) ||
                    !isset($_POST['email']) ||
                    !isset($_POST['mobile']) ||
                    !isset($_POST['company_name']) ||
                    !isset($_POST['company_message'])
                                    
                ) {
                //
            }

        if (empty($_POST['full_name'])){
            $full_name_error = "Full name required";
        } else {
            $full_name = test_input($_POST['full_name']);
            // check if firstname only contains letters and whitespace 
            if(!preg_match("/^[a-zA-Z]*$/", $full_name)) {
                $full_name_error = " Only letters and white space allowed";
            }
        }

       
       if (empty($_POST['email'])){
            $email_error = "Email address is required";
        } else {
            $email = test_input($_POST['email']);
            // check if email address is well-formed
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $email_error = " invalid email address required ";
            }
        }


        if (empty($_POST['mobile'])) {
            $mobile_error = "Mobile number is required";
        } else {
            $mobile = test_input($_POST['mobile']);
            // check if firstname only contains letters and whitespace
            if (!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i", $mobile)) {
                $mobile_error = " Only letters and white space allowed";
            }
        }

        if (empty($_POST['company_name'])){
            $company_name_error = "Company required";
        } else {
            $company_name = test_input($_POST['company_name']);
            // check if firstname only contains letters and whitespace 
            if(!preg_match("/^[a-zA-Z]*$/", $company_name)) {
                $company_name_error = " Only letters and white space allowed";
            }
        }

       if (empty($_POST['message'])){
                $company_message = "";
        } else {
                $company_message = test_input($_POST["message"]);
        }




        if ($full_name_error == "" and $email_error == "" and $mobile_error == "" and $company_name_error == "" and $company_message_error == "" ) {
            $message_body = "";
            unset($_POST['submit']);
            foreach ($_POST as $key => $value) {
                $message_body .= "$key: $value\n";
            }
        }


            function clean_string($string)
                {
                    $bad = array("content-type", "bcc:", "to:", "cc:", "href");
                    return str_replace($bad, "", $string);
            }

            $email_message = "Form details below.\n\n";

                $email_message .= "full_name: " . clean_string($full_name) . "\n";
                $email_message .= "email: " . clean_string($email) . "\n";
                $email_message .= "mobile: " . clean_string($mobile) . "\n";
                $email_message .= "company_name: " . clean_string($company_name) . "\n";
                $email_message .= "company_message: " . clean_string($company_message) . "\n";

               
        // $fourtname = $secondname ;
        // $fourtname .= $middlename;
        // $fourtname .= $state;
        // $fourtname .= $email;
        // $fourtname .= $subject;
        // $fourtname .= $message;

        // return $fourtname;


        $to = "debraintutoradvancedstudies@gmail.com";
        $subject = "Contact Form Submit";
        if (mail($to, $subject, $email_message)) {
             $success = "Message Sent, thanks you for contacting us!";
             $full_name = $email = $mobile = $company_name = $company_message = ""; 
         } else {
            $success = "Message not sent!";
         }


         // $headers = 'From: ' . $firstname . $secondname . "\r\n" .
         // 'Reply-To: ' . $email . "\r\n" .
         // 'X-Mailer: PHP/' . phpversion();
         // @mail($email_to, $email_subject, $fourtname, $headers);



    }





        function test_input($date){
            $date = trim($date);
            $date = stripcslashes($date);
            $date = htmlspecialchars($date);
            return $date;
        }
















// THIS IS THE FIRST TESTED CODE AND IT WORKS PERFECTLY

// Email address verification
// function isEmail($email) {
// 	return filter_var($email, FILTER_VALIDATE_EMAIL);
// }


    
    // $name = addslashes(trim($_REQUEST['name']));
    // $email = addslashes(trim($_REQUEST['email']));
    // $subject = addslashes(trim($_REQUEST['subject']));
    // $message = addslashes(trim($_REQUEST['message']));


    // Enter the email where you want to receive the message
   // $emailTo = 'debraintutor@gmail.com';
   //  if( empty(['name']) || empty(['email']) || empty(['subject']) || empty(['message'])) {
   //      echo "Please fill all the fields";

    // } else {
    //     mail("umaribrahimayobami@gmail.com", $subject, $message, "From: $email < $email");
    //     echo "<script type='text/javascript'> alert ('Your Message Sent succesfully');
    //     window.history.log(-1) </script>";
    // }


    //redirect to the You are succesfully completed you registration
        //header('Location: success.php');



    // THIS IS THE SECOND TESTED CODE AND IT WORKS FINE IT WORKS WITH MYSQL DATABASE SUBMISSION
    
    // if( isset($_POST['name']) || isset($_POST['email']) || isset($_POST['subject']) || isset($_POST['message'])) {
    
    //    $name = mysqli_real_escape_string($connection, $_POST['name']);
    //    $email = mysqli_real_escape_string($connection, $_POST['email']);
    //    $subject = mysqli_real_escape_string($connection, $_POST['subject']);
    //  $message = mysqli_real_escape_string($connection, $_POST['message']);

    //   }

       // $sql = "INSERT INTO contactmessage (name, email, subject, message)
       //   VALUES ('$name', '$email', '$subject',  '$message')";


        //if (mysqli_query($connection, $sql)) {
         //   echo "Records added successfully.";
        //} else {
        //    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
        //}


        //close connection
       // mysqli_close($connection);




?>