/*  media query for (min-width: 320px) and (max-width: 480px) goes here
======================================================= */

@media (min-width: 320px) and (max-width: 480px) {

		.btn-unique {
			background-color: rgba(79,222,218, 1);
			border-color: #ffffff80;
			color: rgba(255, 255, 255, 1) !important;
		}
		
		.btn-unique:hover {
			color: rgba(255, 255, 255, 0.8);
		}
		
		.navbar-toggler {
			background-color: #000000;
			color: #dcb145 !important;
			font-size: 1.2rem !important;
			margin-right: 1.2rem !important;
		}

		header {
			/* background-color: transparent !important; */
			/* background-color: black !important; */
			/* background-color: rgba(0,0,0, 1); */
			background-color: rgba(255,255,255, 1);
			clear: both;
			color: rgba(255, 255, 255, 1);
			height: auto;
			margin: 0;
			min-height: 50px;
			padding: 0;
			position: absolute;
			top: 0;
			width: 100%;
			z-index: 9999;
		}
	
	header .container {
		margin-bottom: 0;
		padding-left: 0;
		padding-right: 0;
		padding-bottom: 0;
		/* background-color:#dcb145; */
			/* background-color:rgb(20,33,55);  */
			background-color: transparent !important;
	}
	
	
	
	header .container  #uppernav
	{
			height: 40px;
			background-color:black !important;
			padding: 0.2rem;
			float: left;
			margin-left: 0;
	}
	
	
	header .container  #uppernav .uppercon
	{
		background-color: transparent !important;
		margin-right: 2px;
		float: left;
		clear: both;
		padding: 0.5rem 0 0 0;
	}
	
	header .container  #uppernav .uppercon h6
	{
		color: #dcb145;
		float: left;
		margin-left: 20px;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
		text-decoration: none !important;
		font-size: 0.6rem;
	}

	header .container  #uppernav .uppercon h6 span
	{
		color: #dcb145;
		font-weight: bolder;
		margin-right: 10px;	
	}
	
	header .container > nav
	{
			padding: 0;
			width: 100% !important;
			/* background-color: rgba(255, 255, 255, 0.8); */
			/* background-color:#dcb145; 
			background-color:rgb(20,33,55); */
			/* background-color: rgba(255, 255, 255, 1); */
			background-color: transparent !important;
			border-bottom: 3px solid black;
	}
	
	
	header .container nav > a
	{
			/* color: rgba(0, 0, 0, 1); */
			font-family: inderRegular;
			margin: 0;
			/* background-color: red !important; */
			padding: 0.4rem 0.5rem;
			overflow: hidden;
			width: 170px;
			height: 60px;
	}
	
	header .container nav > a img {
		float: left;
		margin: 0 0 0 5px;
		height: 50px !important;
		width: 1700px !important;
		padding: 0;

	}
	

 header .container div.collapse {
		background-color:rgb(20,33,55) !important;
		height: auto !important;
		padding-left: 0 !important;
		padding-right: 0 !important;
	} 

		

	 header .container div ul
	{
			margin-top: 1.5rem;
			font-weight: bolder;
			padding: 0rem 1rem 0 1rem !important;
			background-color:yellow !important;
	}

	header .container div ul li
	{
			color: #dcb145 !important; 
			margin: 0;
			font-weight: bolder;
			padding: 0rem !important;
	}
	
	
	header .container div ul li a
	{
			color: #dcb145 !important;
			font-family: inderRegular;
			font-size: 1rem;
			margin: 0 0.5rem;
			padding: 0.5rem;
	}
	
	header .container div ul li a:hover{
		color: #dcb145 !important;
		background-color: white !important;
		font-family: inderRegular;
		font-size: 1rem;
		padding: 0;
		
	} 
	
	 header .container div ul li .dropdown-menu
	{
		background-color: rgb(20,33,55) !important;
		border: none !important;
		box-shadow: none !important;
		margin-top: 20px;
		overflow: hidden;
	} 
	
	header .container div ul li .dropdown-menu .dropdown-item
	{
		font-weight: bolder;
		background-color: rgb(20,33,55) !important;
		color: #dcb145 !important;
		margin-left: 0;
	}
	
	header .container div ul li .dropdown-menu .dropdown-item a:hover
	{
		color: rgb(20,33,55) !important;
		background-color: #dcb145 !important;
	}
	
	
	/* HEADER STYLES END HERE
	-------------------------------------------------------------*/
	
	
	
	main
	{
		clear: both;
		height: auto;
		margin: 0;
		min-height: 80vh;
		padding: 0;
		width: 100%;
	}
	
	/* Banner Style Goes Here
	===================================================== */

	main #banner {
		clear: both;
		height: auto;
		margin: 3rem 0 0 0;
		min-height: 40vh;
		padding: 0;
		text-align: center;
		top: 0;
		width: 100%;
		/* overflow: hidden; */
   }
   
   main #banner #carouselExampleCaptions 
   {
	   width: 100%;
	   height:40vh;
	   margin-top: 50px;
	   background-color: white;
   }
   
   main #banner #carouselExampleCaptions img 
   {
	   width: 100%;
	   height: 40vh;
   }
   
   
   main #banner .carousel-caption
   {
	   background-color: rgba(0, 0, 0, 0.5);
	   clear: both;
	   float: left;
	   height: 20vh !important;
	   left: 0 !important;
	   max-height: 100vh;
	   margin: 0 auto;
	   padding: 0 !important;
	   right:0 !important;
	   text-align: left !important;
	   top: 0rem;
   }
   main #banner .carousel-caption h4
   {
	   color: rgba(255, 255, 255, 1);
	   font-family: inderRegular;
	   font-size: 0.8rem;
	   text-shadow: 1px 1px 1px rgba(100, 100, 100, 1);
   }
   
   main #banner .carousel-caption h5
   {
	   margin: 1rem 0 0 1rem !important;
	   color: rgba(255,255,255, 1);
	   /* font-family: playballregular; */
	   font-family: inderRegular;
	   font-size: 0.5rem;	
	   font-style: italic;
	   font-weight: bolder;
   }
   
   
   main #banner .carousel-caption p {
	   border: 2px solid rgba(20, 20, 20, 1);
	   margin: 0 0 0 10rem;
	   background-color: rgba(0,0,0, 0.7) ;
	   border-radius: 2rem;
	   bottom: -1rem;
	   clear: both;
	   color:#dcb145;
	   font-family: ITCAvantgarde;
	   font-weight: bolder;
	   font-size: 0.9rem;
	   padding: 0rem 0rem;
	   position: relative;
	   text-decoration: none;
   }
   
   /* main #banner .carousel-caption a:hover {
	   text-decoration: none;
	   color:#dcb145;
   } */
   
   
   
   main #banner .carousel-indicators {
	   bottom: 10vh;
	   z-index: 999;
   }
    
   /* IndexAbout Style Goes Here
   ===================================================== */

   
main #indexAbout
{
	/* background-color: rgba(255, 255, 255, 0.5); */
	background-color: #dcb145;
	clear: both;
	margin: 0;
	min-height: 25vh;
	padding: 0 0;
	position: relative;
	width: 100%;
	z-index: 999;
}

main #indexAbout .container
{
	clear: both;
	padding: 1rem;
	text-align: center !important;
}


main #indexAbout .container h3
{
	clear: both;
	color: rgb(20,33,55);
	font-weight: bolder;
	font-family: inderRegular !important;
	/* font-size: 1rem; */
	font-size: 1.2rem;
	padding: 1rem 0 0 0;
}

main #indexAbout .container p
{
	clear: both;
	font-size: 0.8rem;
	padding: 0.5rem 0.7rem 0 0.7rem;
	text-align: justify;
	line-height: 20px;
	font-family: ITCAvantgarde;
	font-weight: bold;
	margin-bottom: 2.5rem;
	
}


/* IndexServices Style Goes Here
===================================================== */


main #indexServices
{
	/* background-color: rgba(255, 255, 255, 0.5); */
	background-color: rgba(20,33,55);
	height: auto;
	margin: 0;
	min-height: 20vh;
	padding: 0;
	width: 100%;
}

main #indexServices
{
	
	color: #dcb145;
	clear: both;
	padding: 2rem 0 2rem 0;
}

main #indexServices .container 
{
	/* background-color: green !important; */
	margin:0;
	padding: 0;
	width: 100%;
	height: auto !important;
	overflow: hidden;
	background-color: rgb(20,33,55);
}


main #indexServices .container h3
{
	clear: both;
	font-family: inderRegular;
	font-size: 1.2rem;
	padding: 1rem 0;
	text-align:left;
	font-weight: bolder;
	margin-left: 1.8rem;
}

main #indexServices .container .spec 
{
	background-color: transparent !important;
	/* background-color: rgb(20,33,55); */
	margin-top: 0 !important;
	clear: left;
	float: left;
	width: 100% !important;
	height: auto !important;
	padding: 1rem 2rem 2rem 3rem;
}

/* main #indexServices .container #first
{
	background-color: rgb(0, 197, 209) !important;
}

main #indexServices .container #second
{
	background-color:blue !important;
}

main #indexServices .container #third
{
	background-color: #c60101 !important;
}

main #indexServices .container #fourth
{
	background-color: rgb(0, 197, 209) !important;
} */


main #indexServices .container .spec h4
{
	font-weight: bolder;
	font-family:ITCAvantgarde;
	font-size: 1.2rem;
}

main #indexServices .container .spec ul
{
	margin-left: 15px;
}

main #indexServices .container .spec ul li
{
	text-decoration: none;
	font-size: 0.8rem;
	margin-top: 1rem;
	color: white;
	font-family: ITCAvantgarde;
	font-weight: bold;
}




/* IndexProduct Style Goes Here
===================================================== */
main #indexProduct
{
	background-color: rgba(255,255,255,1);
	clear: both;
	height: auto;
	margin: 0;
	min-height: 70vh;
	padding: 2.5rem 0;
	width: 100%;	
}

main #indexProduct > .container
{
	margin-bottom: 0rem;
}


main #indexProduct > .container > h3
{
	clear: both;
	font-family: inderRegular;
	font-size: 1.2rem;
	padding: 1rem 0;
	text-align:left;
	font-weight: bolder;
	margin-left: 1.8rem;
}



main #indexProduct > .container #projectrow
{
	padding: 2rem;
	margin-top: 3rem;
}

main #indexProduct > .container #projectrow section
{
	padding: 0.5rem;
}


main #indexProduct > .container #projectrow .proclass
{
	padding-top: 1rem;
}

main #indexProduct > .container #projectrow .proclass:hover
{
	background-color: rgba(200,200,200,0.7);
	/* color: #ffffff; */
	border-bottom: 4px solid black;
	-moz-transition: all 0.6s ease-in ;
	-webkit-transition: all 0.6s ease-in ;
	--transition: all 0.6s ease-in ;
	transition: all 0.6s ease-in;
}


main #indexProduct > .container #projectrow section h4
{
	font-weight: bolder;
	font-family: ITCAvantgarde;
}

main #indexProduct > .container #projectrow section p
{
	font-family: ITCAvantgarde;
	margin-top: 5px;
	font-weight: bold;
}

main #indexProduct > .container #projectrow section p strong
{
	font-weight: bolder;

}




/* IndexTestimonials Style Goes Here
===================================================== */

/* IndexNewsletter Style Goes Here
===================================================== */

main #indexNewsLetter
{
	/* background-color: rgba(255, 255, 255, 0.5); */
	background-color: rgba(20,33,55);
	height: auto;
	margin: 0;
	min-height: 20vh;
	padding: 0;
	width: 100%;
}

main #indexNewsLetter
{
	
	color: #dcb145;
	clear: both;
	font-size: 0 !important;
	padding: 2rem 0 0 0;
}

main #indexNewsLetter .container 
{
	background-color: transparent !important;
	margin:0 0;
	padding: 0 0 2rem 0 !important;
	width: 100%;
	height: auto;
	overflow: hidden;
	/* background-color: rgb(20,33,55); */
}


main #indexNewsLetter .container h3
{
	clear: both;
	font-family: inderRegular;
	font-size: 1.3rem;
	padding: 1rem 0;
	text-align:center;
}

  
  /* Add some padding and a grey background color to containers */
  main #indexNewsLetter .container #subform .sub {
	padding: 5px !important;
	background-color: white;
  }
  
  main #indexNewsLetter .container #subform .sub #inputdiv {
	align-content: center;
	padding: 0 0 0 1rem !important;
	float: left;
	clear: both;
	height: 40vh;
	width: 100%;
  }

  main #indexNewsLetter .container #subform  .sub #inputdiv input[type=text] {
	width: 90%;
	padding: 15px;
	margin-top: 2rem !important;
	border: 3px solid #ccc;
	height: 50px;
	font-size: 1rem;
	color: black;
	font-weight: bolder;
  }


  /* Style the input elements and the submit button */
  main #indexNewsLetter .container #subform input[type=submit] {
	width: 100%;
	padding: 5px;
	margin: 8px 0;
	border: 1px solid #ccc;
	height: 50px;
	font-size: 1rem;
  }
  
  main #indexNewsLetter .container #subform label{
	font-weight: bolder;
	font-size: 1rem;
	letter-spacing: 5px;
	color: black;
	font-family: ITCAvantgarde;
  }

  /* Add margins to the checkbox */
  main #indexNewsLetter .container #subform input[type=checkbox] {
	margin-top: 16px;
	font-size: 0.8rem !important;
	margin-left: 1rem !important;
	width: 15px;
	height: 15px;
  }
  
  /* Style the submit button */
  main #indexNewsLetter .container #subform input[type=submit] {
	background-color: #4CAF50;
	color: white;
	border: none;
	font-weight: bolder;
	letter-spacing: 10px;
	font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  }
  
  main #indexNewsLetter .container #subform input[type=submit]:hover {
	opacity: 0.8;
  }

  /* indexHappy Style Goes Here
===================================================== */
main #indexHappy
{
	background-color: rgba(255, 255, 255, 0.5);
	/* background-color: rgba(20,33,55); */
	height: auto;
	margin: 0;
	min-height: 20vh;
	padding: 0;
	width: 100%;
}

main #indexHappy
{
	
	color: #dcb145;
	clear: both;
	font-size: 4.5rem;
	padding: 2rem 0 0 0;
}

main #indexHappy .container 
{
	background-color: rgba(255, 255, 255, 0.5);
	/* background-color: transparent !important; */
	margin:0 0;
	padding: 0;
	width: 100%;
	height: 75vh;
	overflow: hidden;
	/* background-color: rgb(20,33,55); */
}


main #indexHappy .container h3
{
	clear: both;
	font-family: inderRegular;
	font-size: 3rem;
	padding: 1rem 0;
	text-align:center;
}

/* IndexClient Style Goes Here
===================================================== */


/* 
main #indexDesign
{
	background-color: rgba(200, 200, 200, 0.5);
	clear: both;
	height: auto;
	margin: 0;
	min-height: 80vh;
	padding: 4.5rem 0;
	width: 100%;	
}

main #indexDesign > .container
{
	margin-bottom: 1rem;
}


main #indexDesign > .container > h3
{
	clear: both;
	font-family: inderRegular;
	font-size: 1.3rem;
	padding: 1rem 0;
	text-align:center;
}



main #indexDesign > .container #projectrow
{
	padding: 0rem;
	margin-top: 2rem;
}

main #indexDesign > .container #projectrow div
{
	float: left !important;
	clear: both !important;
}

main #indexDesign > .container #projectrow section
{
	padding: 0.5rem;
}


main #indexDesign > .container #projectrow .proclass
{
	padding-top: 1rem; clear: both;
	float: left !important;
}

main #indexDesign > .container #projectrow .proclass img
{
	width: 50px !important;
	height: 80px !important;
	border-radius: 20px !important;
	background-color: red !important;
	float: left !important;
	clear: both !important;
} */


/* CONTENT STYLES END HERE
-------------------------------------------------------------*/

	footer {
		/* background-color: rgba(50, 50, 50, 0.8); */
		background-color: rgb(20,33,55);;
		bottom: 0;
		clear: both;
		color: rgba(255, 255, 255, 1);
		height: auto;
		margin: 0;
		min-height: 20px;
		padding: 1.5rem 0 0 0;
		position: static;
		width: 100%;
	}

	footer .container 
	{
		padding-top: 2rem 0 0rem;
	}


	footer .container #bottomdiv
	{
		background-color: black;
		padding: 1rem 0rem;
	}

	footer .container #foot 
	{
	margin-bottom:0px ;
	/* background-color: rgb(20,33,55); */
	background-color: transparent !important;
	padding: 0;
	}

	footer .container .footcon 
	{
		height: auto !important ;
		background-color: transparent !important;
		padding-top: 1rem;
		padding-bottom: 2rem;
		padding-left: 2rem;
		border-bottom: 3px solid white; 
	}

	footer .container .footcon form
	{
		padding:1rem 0 0 0;
		margin-left:0 ;
		float: left;	
		font-weight: bolder;
		font-family: ITCAvantgarde;
	}

	footer .container .footcon form input
	{
		background-color: rgba(0, 0, 0, 1);
		color:rgba(255, 255, 255, 0.5);
		font-weight: bolder;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	}

	footer .container .footcon form input:focus
	{
		background-color: rgba(255, 255, 255, 1);
		color:rgba(0,0,0,5);
		font-weight: bolder;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	}


	footer .container .footcon form textarea
	{
		background-color: rgba(0, 0, 0, 1);
		color:rgba(255, 255, 255, 0.5);
		font-weight: bolder;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	}


	footer .container .footcon form textarea:focus
	{
		background-color: rgba(255, 255, 255, 1);
		color:rgba(0,0,0,5);
		font-weight: bolder;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	}

	footer .container .footcon form ::placeholder
	{
		color:rgba(255, 255, 255, 0.5);
		font-size: 0.8rem !important;
		font-weight: bolder;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
	}

	footer .container .footcon form button span
	{
		
		margin-top: 3px;
		margin-right: 3px;
	}

	footer .container div[class*=col] p
	{
		color: rgba(255, 255, 255, 1);
		font-family: inderRegular;
		font-size: 0.8rem !important;
	}

	footer .container div[class*=col] p a
	{
		color: rgba(255, 255, 255, 1);
		font-weight: 900;
		padding: 0 0.2rem;
		text-decoration: none;
	}


	footer .container div[class*=col] h4
	{
		color: #dcb145;
		font-weight: bolder;
		font-family: ITCAvantgarde;
		font-size: 1.1rem;
	}

	footer .container div[class*=col] ul
	{
		float: left;
		margin-left: 0px;	 
		margin-top: 20px;
	}

	footer .container div[class*=col] ul li
	{
		list-style: none;
		color: #ffffff;
		font-weight: bolder;
		font-size: 0.9rem;
		word-spacing: 2px;
		line-height: 30px;
		letter-spacing: 0 !important;
		font-family: ITCAvantgarde !important;
	}

	footer .container div[class*=col] ul li.address
	{
		margin-bottom: 10px;
		line-height: 17px;
		font-family: ITCAvantgarde;
	}

	footer .container div[class*=col] ul li a
	{
		list-style: none;
		color: #ffffff;
		font-weight: bolder;
		font-size: 1rem;
		word-spacing: 2px;
		letter-spacing: 3px;
		font-family: ITCAvantgarde;
	}

	footer .container div[class*=col] ul li a:hover
	{
		text-decoration: none;
		color:rgba(100, 100, 100, 1);
	}

	footer .container div[class*=col] p#lead
	{
		margin-top: 1.5rem;
		list-style: none;
		color: #ffffff;
		font-weight: bolder;
		font-size: 1rem;
		word-spacing: 2px;
		line-height: 25px;
		text-align: justify;
		letter-spacing: 1px;
		font-family: ITCAvantgarde;
		padding-right: 1rem;
	}




}







@media (min-width: 481px) and (max-width: 768px){
	main #banner .carousel-caption
	{
		clear: both;
		float: left;
		height: auto;
		left: 10% !important;
		max-height: 10vh;
		margin: 8vh auto 0 auto;
		padding: 0;
		right: 10% !important;
		text-align: left !important;
		top: 2rem;
	}
	
	main #banner .carousel-caption h4
	{
		color: rgba(255, 255, 255, 1);
		font-family: inderRegular;
		font-size: 1.5rem;
		text-shadow: 1px 1px 1px rgba(100, 100, 100, 1);
	}
	
	main #banner .carousel-caption h5
	{
		color: rgba(20, 20, 20, 1);
		font-family: playballregular;
		font-size: 1.1rem;	
		font-style: italic;
	}
	
	main #banner .carousel-caption a {
		border: 2px solid rgba(20, 20, 20, 1);
		border-radius: 5rem;
		bottom: -1rem;
		clear: both;
		color: rgba(20, 20, 20, 1);
		display: inline-block;
		font-family: inderRegular;
		font-size: 0.65rem;
		padding: 0.8rem 2rem;
		position: relative;
		text-decoration: none;
	}

	main #banner .carousel-indicators {
		bottom: 1vh;
		z-index: 999;
	}  



	@media (min-width: 320px) and (max-width: 480px) {
	main #banner .carousel-caption
	{
		clear: both;
		float: left;
		height: auto;
		left: 5% !important;
		max-height: 10vh;
		margin: 0 auto;
		padding: 0;
		right: 5% !important;
		text-align: left !important;
		top: 5rem;
	}
	
	/* main #banner .carousel-caption h4
	{
		color: rgba(255, 255, 255, 1);
		font-family: inderRegular;
		font-size: 1rem;
		text-shadow: 1px 1px 1px rgba(100, 100, 100, 1);
	} */
	
	/* main #banner .carousel-caption h5
	{
		color: rgba(20, 20, 20, 1);
		font-family: playballregular;
		font-size: 0.8rem;	
		font-style: italic;
	} */
	
	/* main #banner .carousel-caption a {
		border: 2px solid rgba(20, 20, 20, 1);
		border-radius: 5rem;
		bottom: -1rem;
		clear: both;
		color: rgba(20, 20, 20, 1);
		display: inline-block;
		font-family: inderRegular;
		font-size: 0.65rem;
		padding: 0.5rem 1.5rem;
		position: relative;
		text-decoration: none;
	} */

	main #banner .carousel-indicators {
		bottom: 1vh;
		z-index: 999;
	}
}






@media (min-width: 320px) and (max-width: 480px) {
	main #banner .carousel-caption
	{
		clear: both;
		float: left;
		height: auto;
		left: 5% !important;
		max-height: 10vh;
		margin: 0 auto;
		padding: 0;
		right: 5% !important;
		text-align: left !important;
		top: 5rem;
	}
	
	/* main #banner .carousel-caption h4
	{
		color: rgba(255, 255, 255, 1);
		font-family: inderRegular;
		font-size: 1rem;
		text-shadow: 1px 1px 1px rgba(100, 100, 100, 1);
	} */
	
	/* main #banner .carousel-caption h5
	{
		color: rgba(20, 20, 20, 1);
		font-family: playballregular;
		font-size: 0.8rem;	
		font-style: italic;
	} */
	
	/* main #banner .carousel-caption a {
		border: 2px solid rgba(20, 20, 20, 1);
		border-radius: 5rem;
		bottom: -1rem;
		clear: both;
		color: rgba(20, 20, 20, 1);
		display: inline-block;
		font-family: inderRegular;
		font-size: 0.65rem;
		padding: 0.5rem 1.5rem;
		position: relative;
		text-decoration: none;
	} */

	main #banner .carousel-indicators {
		bottom: 1vh;
		z-index: 999;
	}
}


main #indexWhoweare {
		height: auto !important;
		padding: 0;
		margin-top: 6rem !important;
		overflow: hidden;
	}

	main #indexWhoweare > #banner{
		/* background: green; */
		height: auto !important;
		margin: 0;
		position: relative;
	}


	main #indexWhoweare > #banner img{
		/* background: green; */
		position: absolute;
		height: 30vh !important;
		margin: 0 auto;
		left: 0;
		right: 0;
		text-align: center;
	}


	main #indexWhoweare > #banner h3{
		/* background: green; */
		position: absolute;
		text-align: center;
		width: 100%;
		margin: 5rem 0 0 0 ;
		font-size: 2rem !important;
		color: white;
		-webkit-text-stroke: 1.5px black ;
		font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
		font-weight: bolder;
		font-size: 1.4rem !important;
	}


	main #indexWhowearetext {
		height: auto ;
		padding: 0 0 5rem 0 !important;
		margin-top: 0rem;
	}

	main #indexWhowearetext > #text {
		padding: 0rem 2rem 2rem !important ;
		height: 80vh !important;
		margin-bottom: 0px;	
	}

	main #indexWhowearetext > #text h2,.h2i{
		/* background: green; */
		font-family: inderRegular;
		font-weight: bolder;
		color: #dcb145;
		font-size: 1rem !important;
		margin-top: 0 !important;
	}

	main #indexWhowearetext > #text p{
		font-family: ITCAvantgarde;
		margin-top: 1rem !important;
		line-height: 20px;
		font-size: 0.8rem;
		text-align: justify;
	}
