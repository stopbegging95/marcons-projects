<?php include("include/header.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
        <div class="container-fluid" id="indexOurteam">
                <div class="container col-12" id="banner">
                    <img src="images/3.jpg" alt="..." style="width:100%">
                
                        <h3> ABOUT US - <i> Our Team </i> </h3>
                </div>

        </div>


        <div class="container-fluid" id="indexOurteamtext">

                <div class="container col-12" id="text">
                
                    <h2> ABOUT US - <i> Our Team </i> </h2>
                        <p>  MARCONS is a company driven to provide quality construction management and development services to our clients. 
                            Working as a team, each one contributing in building the best, meeting the diverse needs of the people we serve, 
                            using technology, research and innovation to build projects that last..
                        </p>
                        <div class="card-deck">
                                <div class="card col-sm-6 col-md-3 col-lg-3 wow slideInDown ">
                                <img src="images/ceo.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                <h5 class="card-title">Mr. GAZAL Tajudeen Obasanjo</h5>
                                </div>
                                <div class="card-footer">
                                <p class="card-text"> <strong> POST:</strong> Project Director</p>
                                </div>
                                </div>
                                <div class="card col-sm-6 col-md-3 col-lg-3 wow slideInLeft">
                                <img src="images/mod.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                <h5 class="card-title">Mr. ALAMU Olamide M</h5>
                                </div>
                                <div class="card-footer">
                                <p class="card-text"><strong> POST:</strong> Creative Director and Quantity Surveyor</p>
                                </div>
                                </div>
                                <div class="card col-sm-6 col-md-3 col-lg-3 wow slideInDown">
                                <img src="images/md.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                <h5 class="card-title">Mr. AKINTOLA Olanrewaju Samuel</h5>
                                </div>
                                <div class="card-footer">
                                <p class="card-text"> <strong> POST:</strong>  Architect </p>
                                </div>
                                </div>
                                <div class="card col-sm-6 col-md-3 col-lg-3 wow slideInRight">
                                <img src="images/mod.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                <h5 class="card-title">Mr. COMING UP SO SOON</h5>
                                </div>
                                <div class="card-footer">
                                <p class="card-text"><strong> POST:</strong> Engineer</p>
                                </div>
                                </div>
                               
                        </div>


                </div>


        </div>

      


<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	