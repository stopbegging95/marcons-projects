<?php include("include/header.php"); ?>
<?php include("formreceive.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
        <div class="container-fluid" id="indexContact">
                <div class="container col-12" id="banner">
                    <img src="images/3.jpg" alt="..." style="width:100%">
                
                        <h3> CONTACT US </h3>
                </div>
        </div>


        <div class="container-fluid" id="indexContactext">

                <div class="container col-12" id="text">
                
                    <h2> CONTACT US </h2>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-7 col-lg-7 contactcon">
                              
                                <h4> SEND US A MESSAGE</h4>
                        
                              
                                    
                              <form class="col-11" action=" <?=$_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                                <div class="success"> <?= $success ?? '' ?> </div>
                                                <div class="form-group">
                                                <input type="text" name="full_name" class="form-control" id="full_name" placeholder="Full Name"  value="<?= $full_name ?? '' ?>" required />
                                                <span class="error"><?= $full_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="email" name="email" class="form-control" id="email" placeholder="name@example.com"  value="<?= $email ?? '' ?>" required />
                                                <span class="error"><?= $email_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="tel" name="mobile" class="form-control" id="mobile" placeholder="Phone No: +(234)-8165-371-302" value="<?= $mobile ?? '' ?>" required  />
                                                <span class="error"><?= $mobile_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="text" name="company_name" class="form-control" id="companyname" placeholder="Company Name"  value="<?= $company_name ?? '' ?>" required />
                                                <span class="error"><?= $company_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <textarea type="text" name="company_message" class="form-control" id="exampleFormControlTextarea1" placeholder="Type your message" rows="3" value="<?= $company_message ?? '' ?>" required ></textarea>
                                                <span class="error"><?= $company_message_error ?? '' ?></span>
                                                </div>
                                        <button class="btn btn-success" name="submit" value="submit" type="submit"> <span class="glyphicons glyphicons-circle-arrow-right"> </span> Send Message</button>
                              </form>
                           </div>
                             
                             <div class="col-xs-12 col-sm-6 col-md-5 col-lg-5 contactcon" id="contactInfodiv">
                              
                                <h4> CONTACT INFO</h4>
                              
                              <form class="col-12" >
                                        <div class="form-group" >
                                            <p> You can contact or visit us in our office from Monday to Friday from 8:00 AM - 6:00 PM </p>
                                        </div>
                                        <div class="row info">
                                                <div class="col-1"> 
                                                        <i class="fa fa-map-marker"> </i>
                                                </div>
                                                <div class="col-10"> 
                                                        <p>You can contact or visit us in our office from Monday to Friday from 8:00 AM - 6:00 PM </p>
                                                </div>
                                        </div>
                                        <br>
                                        <hr>
                                        <div class="row info">
                                                <div class="col-1"> 
                                                        <i class="fa fa-phone"> </i>
                                                </div>
                                                <div class="col-8"> 
                                                        <p>  +(234)-8129-963-050 </p>
                                                        <p>  +(234)-8038-452-144 </p>
                                                </div>
                                        </div>
                                        <br>
                                        <hr>
                                        <div class="row info">
                                                <div class="col-1"> 
                                                        <i class="fa fa-envelope-o"> </i>
                                                </div>
                                                <div class="col-6"> 
                                                        <p>  lamavens2020@gmail.com </p>
                                                       
                                                </div>
                                        </div>

                              </form>
     			            </div>
                        </div>
                </div>
        </div>

        <div id="indexNewsLetter" class="container-fluid">
  <div class="wow rotateInDownRight container col-12">

     <h3> Subscribe Now To Our News Letter </h3>
  
                    
          <form id="subform" class="col-sm-10 offset-sm-1 col-lg-8 offset-lg-2" action="action_page.php">

               <div class="sub col-12 ">
                   
                    <div id="inputdiv" class="col-lg-12"> 
                         <input class="inp col-lg-5 col-sm-5" type="text" placeholder="Name" name="name" required>
                         <input class=" col-lg-5 col-sm-5" type="text" placeholder="Email address" name="mail" required>
                    </div> 


                    <label>
                         <input type="checkbox" name="subscribe"> Daily Newsletter
                    </label>
               </div>

               <div class="contsubainer">
               <input type="submit" value="Subscribe">
               </div>
          </form>
          
  </div>
</div>

</div>
      
        <script>
        Example starter JavaScript for disabling form submissions if there are invalid fields
        (function() {
        'use strict';
        window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
                if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
                }
                form.classList.add('was-validated');
        }, false);
        });
        }, false);
        })();


        </script>

<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	