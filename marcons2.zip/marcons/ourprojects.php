<?php include("include/header.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
            <div class="container-fluid" id="indexOurProJect">
                    <div class="container col-12" id="banner">
                        <img src="images/3.jpg" alt="..." style="width:100%">
                    
                            <h3> OUR PROJECTS </h3>
                    </div>

            </div>


        <div class="container-fluid" id="indexOurProJecttext">

            <div class="container col-12" id="text">
                
                    <h2> PROJECTS </h2>
                        <p> MARCONS is one of the most competent construction firm in Nigeria.
                            How does that apply to you? With our level of competency and quality, we understand that each project, whether a # 1 million project or # 10 million project is uniquely important to us and you.
                            Delivering a quality project each time is the foundation of MARCONS.
                        </p>
                      
                        <div class="card-deck">
                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured45.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> DESTINY HOUSE CONSTRUCTION </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Location: Along Oyewunmi Street, Shekoni Area </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured25.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured40.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured26.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured27.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured30.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured31.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            


                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured49.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> PROPOSED SHOPPING COMPLEX </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal2">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel2">Location: </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls2" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured48.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured20.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured50.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured37.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> PROPOSED BUILDING DESIGN FOR TUNDEX VENTURES  </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal3">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel3" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel3">Location:  </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls3" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured47.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured39.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls3" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls3" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="card-deck">
                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> YOACO BUNGALOW CONSTRUCTION </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal4">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel4" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel4">Location: Yoaco Area, Off Ilorin Road Ogbomoso </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls4" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured51.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured52.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured53.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls4" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls4" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            


                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured20.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> CONSTRUCTION OF THE SHOPPING COMPLEX </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal5">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal5" tabindex="-1" aria-labelledby="exampleModalLabel5" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel5">Location: </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls5" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured18.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured41.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured42.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls5" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls5" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="card col-xs-12 col-sm-4 col-md-4 col-lg-4 wow slideInDown ">
                                    <img src="images/featured37.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title"> TUNDEX VENTURES RE-CONSTRUCTION </h5>
                                        </div>
                                <div class="card-footer">
                                <!-- <p class="card-text"> <strong> POST:</strong> Project Director</p> -->

                                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal6">
                                        View More
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal6" tabindex="-1" aria-labelledby="exampleModalLabel6" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel6">Location:  </h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div id="carouselExampleControls6" class="carousel slide" data-ride="carousel">
                                                                <div class="carousel-inner">
                                                                    <div class="carousel-item active">
                                                                        <img src="images/featured47.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                    <div class="carousel-item">
                                                                        <img src="images/featured39.jpg" class="d-block w-100" alt="...">
                                                                    </div>
                                                                </div>
                                                            <a class="carousel-control-prev" href="#carouselExampleControls6" role="button" data-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Previous</span>
                                                            </a>
                                                            <a class="carousel-control-next" href="#carouselExampleControls6" role="button" data-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>


                                                            <!-- <img src="images/ceo.jpg" class="card-img-top" alt="..."> -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>


            </div>
        </div>






        

      


<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	