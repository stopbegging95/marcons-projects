      
                              <!-- <form class="col-11" action="
                              <?= //$_SERVER['PHP_SELF']; ?>" 
                              method="post" enctype="multipart/form-data"> -->
                              <!-- <form class="col-11" action="formreceive.php" method="post" enctype="multipart/form-data">
                                <div class="success"> <?= //$success ?? '' ?> </div>
                                                <div class="form-group">
                                                <input type="text" name="full_name" class="form-control" id="full_name" placeholder="Full Name"  value="<?= $full_name ?? '' ?>" required />
                                                <span class="error"><?= //$full_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="email" name="email" class="form-control" id="email" placeholder="name@example.com"  value="<?= $email ?? '' ?>" required />
                                                <span class="error"><?= //$email_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="tel" name="mobile" class="form-control" id="mobile" placeholder="Phone No: +(234)-8165-371-302" value="<?= $mobile ?? '' ?>" required  />
                                                <span class="error"><?= //$mobile_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <input type="text" name="company_name" class="form-control" id="companyname" placeholder="Company Name"  value="<?= $company_name ?? '' ?>" required />
                                                <span class="error"><?= //$company_name_error ?? '' ?></span>
                                                </div>
                                                <div class="form-group">
                                                <textarea type="text" name="company_message" class="form-control" id="exampleFormControlTextarea1" placeholder="Type your message" rows="3" value="<?= $company_message ?? '' ?>" required ></textarea>
                                                <span class="error"><?= //$company_message_error ?? '' ?></span>
                                                </div>
                                        <button class="btn btn-success" name="submit" value="submit" type="submit"> <span class="glyphicons glyphicons-circle-arrow-right"> </span> Send Message</button>
                              </form> -->