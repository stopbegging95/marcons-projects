<?php

$email_to = "lamavens2020@gmail.com";
$email_subject = "Client Complain";

    // variable setting
    $full_name = $_REQUEST['full_name'];
    $email = $_REQUEST['email'];
    $mobile = $_REQUEST['mobile'];
    $company_name = $_REQUEST['company_name'];
    $company_message = $_REQUEST['company_message'];

    // check input fields

    if (empty($full_name) || empty($email) || empty($mobile) || empty($company_name) || empty($company_message))   
    {
        echo " Please fill the form";
    }
    else
    {
        mail($email_to, $email_subject, $company_message, "From: $full_name <$email>" );
        echo "<script type='type/javascript' > alert('Your Message Is Send Successful');
            window.history.log(-1);
        </script>"; 
    }
?>