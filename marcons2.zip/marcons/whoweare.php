<?php include("include/header.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
        <div class="container-fluid" id="indexWhoweare">
                <div class="container col-12" id="banner">
                    <img src="images/3.jpg" alt="..." style="width:100%">
                
                        <h3> ABOUT US - <i class="h3i"> Who We Are </i> </h3>
                </div>

        </div>


        <div class="container-fluid" id="indexWhowearetext">

                <div class="container col-12" id="text">
                
                    <h2> ABOUT US - <i class="h2i"> Who We Are </i> </h2>

                        <p>

                            MARCONS is a company driven to provide quality construction management and development services to our clients. 
                            Working as a team, each one contributing in building the best, meeting the diverse needs of the people we serve, 
                            using technology, research and innovation to build projects that last.
                                    <br> <br>
                            MARCONS is one of the most competent construction firm in Nigeria.
                            How does that apply to you? With our level of competency and quality, we understand that each project, whether a # 1 million project or # 10 million project is uniquely important to us and you.
                            Delivering a quality project each time is the foundation of MARCONS.

                        </p>
                </div>


        </div>

      


<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	