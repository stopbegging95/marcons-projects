<?php include("include/header.php"); ?>
     <main>
<!-- #BeginEditable "body" -->
        <div class="container-fluid" id="indexBlog">
                <div class="container col-12" id="banner">
                    <img src="images/3.jpg" alt="..." style="width:100%">
                
                        <h3> BLOG NEWS </i> </h3>
                </div>

        </div>


        <div class="container-fluid" id="indexBlogtext">

                <div class="container col-12" id="text">
                
                    <h2> BLOG NEWS </h2>

                        <p>

                            Mmarcons Blog News Coming Soon !!!

                        </p>
                </div>


        </div>

      


<!-- #EndEditable -->
	</main>
<?php include("include/footer.php"); ?>
	